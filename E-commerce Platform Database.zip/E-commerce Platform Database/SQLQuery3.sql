
--Retrieve all products within a specific category:
SELECT p.name, p.description, p.price 
FROM Products p
JOIN ProductCategoriess pc ON p.Product_id = pc.Product_id
JOIN Categories c ON pc.Category_id = c.category_id
WHERE c.name = 'Electronics';


--Fetch a user�s order history:
SELECT o.order_id, o.total_amount, o.status, o.date
FROM Orders o
JOIN Users u ON o.user_id = u.user_id
WHERE u.email = 'sa33@gmail.com';


--Calculate total sales from a specific time period:
SELECT SUM(amount) AS total_sales
FROM Payments
WHERE [date] BETWEEN '2024-01-01' AND '2024-12-31';



--Update product stock after an order is placed:
UPDATE Products 
SET stock = stock - (SELECT quantity FROM OrderItems WHERE product_id = Products.product_id AND order_id = 1)
WHERE product_id IN (SELECT product_id FROM OrderItems WHERE order_id = 1);





